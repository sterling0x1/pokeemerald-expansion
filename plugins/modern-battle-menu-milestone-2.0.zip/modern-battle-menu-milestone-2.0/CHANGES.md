# How the battle menu was achieved

1. **Window layout** — The original four separate move windows were rearranged into one larger left panel and a matching right information panel. This frees enough vertical space for four moves and a three-line description.
2. **Custom renderer** — `src/battle_controller_player.c` manually redraws the move rows and right-panel contents whenever the selected move changes. It no longer relies on the vanilla PP/type layout.
3. **Compact font** — A dedicated `FONT_COMPACT` was added with an 8px thin glyph sheet. Normal game text is unaffected.
4. **Word wrapping** — `BuildCompactDescriptionLine` fits only complete words within the available width, so descriptions remain readable rather than being cut off.
5. **Compressed metadata** — Power, accuracy, and move type share the final row (`P50 A100 Fire`) instead of consuming separate lines.
6. **Effectiveness indicator** — The panel evaluates the selected move against the opponent with the same battle type-effectiveness multiplier used by combat. It draws a custom 8px arrow directly into the window pixels. The two unused green entries in the battle text palette were populated specifically for this icon.
7. **Vanilla prompt removal** — The old `L MOVE INFO` sprite is not created in compact move-selection paths. The custom right panel permanently replaces its purpose, keeping the left edge of the battle screen clean.

The result was tested in battle with super-effective, resisted, immune, neutral, and status moves.
