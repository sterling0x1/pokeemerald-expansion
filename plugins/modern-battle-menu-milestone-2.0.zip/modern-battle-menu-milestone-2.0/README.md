# Modern Battle Menu — Milestone 2.0

Reusable battle-menu package extracted from this working `pokeemerald-expansion` project.

## What it adds

- One compact left panel with four vertically listed moves and PP.
- A matching right panel with three word-wrapped description lines.
- A compact final metadata row: `P50 A100 Fire`.
- Thin 8px battle font designed for these panels.
- A custom pixel effectiveness marker after the type:
  - green up arrow: super-effective;
  - red down arrow: resisted;
  - grey X: no effect;
  - no marker for status moves or neutral damage.
- Removes the vanilla `L MOVE INFO` sprite, because the right panel already provides that information continuously.
- Effectiveness preview is local to this custom panel. It does **not** alter the project's global seen/caught effectiveness-display setting.

## Package contents

`sources/` mirrors the project paths of every battle-menu dependency. These are complete, working source-file copies from Milestone 2.0.

| File | Purpose |
| --- | --- |
| `include/text.h` | Registers `FONT_COMPACT`. |
| `include/fonts.h` | Declares the compact font glyph data. |
| `src/fonts.c` | Loads `latin_compact_thin.png`. |
| `src/text.c` | Gives the font its 8px size, glyph metrics, and text-printer support. |
| `src/battle_bg.c` | Positions and sizes the compact battle windows. |
| `src/battle_controller_player.c` | Draws the move list, compact info panel, word wrapping, type-chart preview, pixel arrows, and suppresses the redundant vanilla `L MOVE INFO` sprite. |
| `src/battle_message.c` | Integrates the compact move UI into battle message flow. |
| `graphics/fonts/latin_compact_thin.png` | The final thin compact font. |
| `graphics/battle_interface/text.pal` | Adds green shades in unused palette slots 6–7 for the effectiveness arrow. |

## Install into another pokeemerald-expansion hack

1. Start from a clean, building project on a compatible `pokeemerald-expansion` revision.
2. Back up every destination file in the target hack.
3. Compare each file in `sources/` against the target's matching file. Merge the documented battle-menu changes; do not blindly overwrite a target file that has unrelated custom work.
4. Copy the compact font graphic to `graphics/fonts/latin_compact_thin.png`.
5. Merge the two green palette slots from `graphics/battle_interface/text.pal`. Keep all other target palette colours unchanged.
6. Build, then test move selection in a single battle and a double battle.

## Important implementation notes

- The compact font is deliberately separate from the normal game font, so its thin style affects only this menu.
- The three-line description renderer wraps at whole words. It prevents text from being clipped at the right edge.
- The effect marker is drawn directly into the window as pixels, rather than through a font glyph. This is why it remains clear at 8px.
- The local effectiveness calculation respects battle abilities and held-item type modifiers, but bypasses the vanilla UI's seen/caught visibility gate. It is used only for the compact indicator.
- The vanilla `TryToAddMoveInfoWindow` calls are deliberately omitted from compact move-selection paths. This prevents the old left-side `L MOVE INFO` prompt from overlapping the redesigned screen.

## Test checklist

- Fire vs Bug: green up arrow.
- Fire vs Water/Rock: red down arrow.
- Normal vs Ghost: grey X.
- Neutral damaging move: no arrow.
- Status move: no arrow.
- Long move description: wraps across up to three rows without clipping.
- Four moves with PP: left-panel alignment remains intact.

## Deliberately excluded

Debug menu, overworld Pokémon encounters, and random-encounter configuration are project features, not dependencies of this battle-menu package.

## Provenance

This package documents the working state tagged `milestone-2.0` in the source project.
